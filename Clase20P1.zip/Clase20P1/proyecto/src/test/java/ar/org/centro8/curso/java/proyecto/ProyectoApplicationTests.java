package ar.org.centro8.curso.java.proyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}
